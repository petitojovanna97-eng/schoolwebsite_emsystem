<?php
session_start();

// ================== Database Class ==================
class Database {
    private $host = "localhost";
    private $user = "root";
    private $pass = "";
    private $dbname = "anahaway_db";
    public $conn;

    public function __construct() {
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->dbname);
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }
}

// ================== School Data Class ==================
class SchoolManager {
    private $db;

    public function __construct($dbConn) {
        $this->db = $dbConn;
    }
    public function getStats() {
    $result = $this->db->query("SELECT * FROM school_stats");
    return $result->fetch_all(MYSQLI_ASSOC);
}


    public function getCourses() {
        // Mock data - replace with $this->db->query("SELECT...")
        return [
            ['title' => 'Science', 'desc' => 'Academic foundation in STEM.'],
            ['title' => 'Mathematics', 'desc' => 'Advanced numerical logic.'],
            ['title' => 'English', 'desc' => 'Literature and communication.'],
            ['title' => 'Technology', 'desc' => 'Digital literacy and innovation.']
        ];
    }
}

// ================== Initialization ==================
$db = new Database();
$school = new SchoolManager($db->conn);

$stats = $school->getStats();
$courses = $school->getCourses();

// Include the view file (the HTML)
include './views/home.php';
?>