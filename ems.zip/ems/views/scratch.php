<!-- dashboard.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enrollment Management System / Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #2563eb;
            --dark: #0f172a;
            --bg: #f1f5f9;
            --card: #ffffff;
            --text: #1e293b;
            --muted: #64748b;
            --border: #e2e8f0;
        }

        * {
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--bg);
        }

        /* Layout */
        .wrapper {
            display: flex;
            height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--dark);
            color: #fff;
            padding: 20px;
            transition: .3s;
            overflow-y: auto;
        }

        .sidebar.collapsed {
            width: 80px;
        }

        .sidebar h2 {
            font-size: 18px;
            margin-bottom: 25px;
        }

        .menu-item {
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
            margin-bottom: 6px;
            font-size: 14px;
            transition: .2s;
        }

        .menu-item:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .submenu {
            display: none;
            padding-left: 15px;
        }

        .submenu div {
            padding: 8px;
            font-size: 13px;
            color: #cbd5e1;
            cursor: pointer;
        }

        .submenu div:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .active+.submenu {
            display: block;
        }

        /* Main */
        .main {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        /* Topbar */
        .topbar {
            background: var(--card);
            padding: 15px 25px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .toggle {
            cursor: pointer;
            font-size: 18px;
        }

        .role-select {
            padding: 6px;
            border-radius: 6px;
        }

        /* Content */
        .content {
            padding: 30px;
        }

        .card {
            background: var(--card);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            cursor: pointer;
            transition: all .25s ease;
            position: relative;
            overflow: hidden;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
        }

        .card:active {
            transform: scale(.98);
        }


        .section {
            margin-top: 30px;
        }

        .section h2 {
            margin-bottom: 15px;
        }

        .activity {
            background: var(--card);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
            font-size: 14px;
        }

        .menu-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .menu-item.active .arrow {
            transform: rotate(180deg);
        }

        .arrow {
            transition: 0.3s;
            font-size: 10px;
        }

        .submenu div {
            padding: 10px 15px;
            border-radius: 6px;
            margin: 2px 0;
            transition: 0.2s;
        }

        .submenu div:hover {
            background: var(--primary);
            /* Highlights the sub-item with your primary blue */
            color: white !important;
        }
    </style>
</head>

<body>

    <div class="wrapper">

        <div class="sidebar" id="sidebar">

            <h2 onclick="location.reload()" style="cursor:pointer">EMS System</h2>

            <div class="menu-item" onclick="openSection('dashboard')">
                <i class="fa-solid fa-chart-line"></i> Dashboard
            </div>

            <div class="menu-item admin-only" onclick="toggleMenu(this)">
                User Management <span class="arrow">▾</span>
            </div>
            <div class="submenu admin-only">
                <div onclick="openSection('add-admin')">Add Admin</div>
                <div onclick="openSection('add-teacher')">Add Teacher</div>
                <div onclick="openSection('view-users')">View Users</div>
                <div onclick="openSection('assign-roles')">Assign Roles</div>
            </div>

            <div class="menu-item" onclick="toggleMenu(this)">
                Student Management <span class="arrow">▾</span>
            </div>
            <div class="submenu">
                <div onclick="openSection('add-student')">Add Student</div>
                <div onclick="openSection('student-list')">Student List</div>
                <div onclick="openSection('academic-history')">Academic History</div>
                <div onclick="openSection('promote-student')">Promote Student</div>
            </div>

            <div class="menu-item" onclick="toggleMenu(this)">
                Enrollment <span class="arrow">▾</span>
            </div>
            <div class="submenu">
                <div onclick="openSection('new-enrollment')">New Enrollment</div>
                <div onclick="openSection('re-enrollment')">Re-Enrollment</div>
                <div onclick="openSection('enrollment-approval')">Enrollment Approval</div>
                <div onclick="openSection('enrollment-status')">Enrollment Status</div>
            </div>

            <div class="menu-item" onclick="openSection('reports')">Reports</div>
            <div class="menu-item" onclick="openSection('settings')">Settings</div>

            <hr style="opacity: 0.1; margin: 10px 0;">

            <a href="auth.php?logout=true" class="menu-item" style="color:#fb7185; text-decoration:none;">
                <strong>Logout</strong>
            </a>

        </div>

        <!-- Main -->
        <div class="main">

            <!-- Topbar -->
            <div class="topbar">
                <div>
                    <span class="toggle" onclick="toggleSidebar()"></span>
                </div>
                <div>
                    Role:
                    <select class="role-select" onchange="changeRole(this.value)">
                        <option value="Admin">Admin</option>
                        <option value="Registrar">Registrar</option>
                        <option value="Teacher">Teacher</option>
                    </select>
                </div>
            </div>

            <!-- Content -->
            <div class="content">

                <h1>Enrollment Dashboard</h1>

                <div class="cards">

                    <div class="card" onclick="openSection('students')">
                        <h3>Total Students</h3>
                        <p id="totalStudents">0</p>
                    </div>

                    <div class="card" onclick="openSection('enrolled')">
                        <h3>Total Enrolled</h3>
                        <p id="totalEnrolled">0</p>
                    </div>

                    <div class="card" onclick="openSection('slots')">
                        <h3>Available Slots</h3>
                        <p id="totalSlots">0</p>
                    </div>

                    <div class="card" onclick="openSection('sections')">
                        <h3>Active Sections</h3>
                        <p>12</p>
                    </div>

                </div>


                <div class="section">
                    <h2>Recent Activities</h2>
                    <div class="activity">blank enrolled in Grade 10 - Section A</div>
                    <div class="activity">blank Smith promoted to Grade 11</div>
                    <div class="activity">New subject added: Science 101</div>
                </div>

            </div>
        </div>

    </div>

    <script>
        function openSection(section) {
            // You can replace these alerts with: window.location.href = section + ".php";
            switch (section) {
                case 'dashboard':
                    console.log("Loading Dashboard...");
                    break;
                case 'add-admin':
                case 'add-teacher':
                    alert("Opening User Creation Form...");
                    break;
                case 'student-list':
                case 'students':
                    alert("Loading Student Database...");
                    break;
                case 'new-enrollment':
                    alert("Starting New Enrollment Process...");
                    break;
                case 'reports':
                    alert("Generating System Reports...");
                    break;
                case 'settings':
                    alert("Opening System Settings...");
                    break;
                case 'logout':
                    confirmLogout();
                    break;
                default:
                    alert("Navigating to: " + section.replace('-', ' '));
            }
        }

        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                alert("Logged out successfully.");
                // window.location.href = "login.php";
            }
        }

        // Keep your existing toggleMenu and toggleSidebar functions below 
        function openSection(section) {

            switch (section) {

                case 'students':
                    alert("Opening Student List Page...");
                    break;

                case 'enrolled':
                    alert("Opening Enrollment Records...");
                    break;

                case 'slots':
                    alert("Opening Section Slot Management...");
                    break;

                case 'sections':
                    alert("Opening Section Management...");
                    break;

                default:
                    alert("Section not found");
            }

        }

        // Sample Data (Mock Database)
        let totalStudents = 520;
        let totalEnrolled = 480;
        let totalSlots = 40;

        // Load Stats
        document.getElementById("totalStudents").innerText = totalStudents;
        document.getElementById("totalEnrolled").innerText = totalEnrolled;
        document.getElementById("totalSlots").innerText = totalSlots;

        // Sidebar Toggle
        function toggleSidebar() {
            document.getElementById("sidebar").classList.toggle("collapsed");
        }

        // Dropdown Toggle
        function toggleMenu(element) {
            element.classList.toggle("active");
        }

        // Role-Based Menu
        function changeRole(role) {
            const adminItems = document.querySelectorAll(".admin-only");

            if (role === "Admin") {
                adminItems.forEach(item => item.style.display = "block");
            } else {
                adminItems.forEach(item => item.style.display = "none");
            }
        }
    </script>

</body>

</html>