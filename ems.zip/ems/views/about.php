<?php include 'nav/header.php'; ?>

<style>
    :root {
        --primary: #0f172a;
        --accent: #ff4b2b;
        --blue: #3b82f6;
        --light: #f8fafc;
    }

    body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background: var(--light);
        color: #1e293b;
    }

    /* ================= HERO ================= */
    .about-hero {
        background: linear-gradient(120deg, #0f172a, #1e293b, #0f172a);
        background-size: 200% 200%;
        animation: gradientMove 10s ease infinite;
        padding: 140px 0 120px;
        color: #fff;
        position: relative;
        overflow: hidden;
    }

    @keyframes gradientMove {
        0% {
            background-position: 0% 50%;
        }

        50% {
            background-position: 100% 50%;
        }

        100% {
            background-position: 0% 50%;
        }
    }

    .hero-title {
        font-size: 3.5rem;
        font-weight: 800;
        line-height: 1.1;
    }

    .hero-title span {
        color: var(--accent);
    }

    .hero-sub {
        opacity: .8;
        max-width: 550px;
    }

    .glass-stat {
        backdrop-filter: blur(15px);
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 20px;
        padding: 25px;
        transition: .4s;
    }

    .glass-stat:hover {
        transform: translateY(-6px);
        background: rgba(255, 255, 255, 0.15);
    }

    /* ================= ACTION CARDS ================= */
    .action-card {
        background: #fff;
        border-radius: 20px;
        padding: 40px 25px;
        text-align: center;
        transition: .4s;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
    }

    .action-card i {
        font-size: 2.5rem;
        margin-bottom: 20px;
        color: var(--accent);
    }

    .action-card:hover {
        transform: translateY(-12px);
        background: var(--accent);
        color: #fff;
    }

    .action-card:hover i {
        color: #fff;
    }

    /* ================= SECTION TITLE ================= */
    .section-title {
        font-weight: 800;
        font-size: 1.8rem;
        position: relative;
        display: inline-block;
        margin-bottom: 40px;
    }

    .section-title::after {
        content: "";
        position: absolute;
        width: 60%;
        height: 4px;
        background: var(--accent);
        left: 0;
        bottom: -8px;
        border-radius: 4px;
    }

    /* ================= STORY ================= */
    .story-img {
        border-radius: 20px;
        overflow: hidden;
        transition: .4s;
    }

    .story-img:hover {
        transform: scale(1.03);
    }

    /* ================= ENROLLMENT CARD ================= */
    .enrollment-card {
        background: #fff;
        border-radius: 30px;
        padding: 40px;
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.05);
    }

    .progress {
        height: 8px;
        border-radius: 10px;
    }

    .progress-bar {
        background: var(--accent);
    }

    /* ================= ANIMATION ================= */
    .reveal {
        opacity: 0;
        transform: translateY(30px);
        transition: 1s ease;
    }

    .reveal.active {
        opacity: 1;
        transform: translateY(0);
    }
</style>


<!-- ================= HERO ================= -->
<section class="about-hero">
    <div class="container">
        <div class="row align-items-center g-5">

            <div class="col-lg-7">
                <h1 class="hero-title">
                    Excellence in <span>Education</span>
                </h1>
                <p class="hero-sub mt-3">
                    Since 1994, ANHS has shaped leaders, innovators,
                    and future-ready students through academic excellence and character formation.
                </p>

                <div class="row g-3 mt-4">
                    <div class="col-md-4">
                        <div class="glass-stat text-center">
                            <h3 class="fw-bold">3,200+</h3>
                            <small>Students</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="glass-stat text-center">
                            <h3 class="fw-bold">120+</h3>
                            <small>Faculty</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="glass-stat text-center">
                            <h3 class="fw-bold">30+</h3>
                            <small>Awards</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 text-center">
                <i class="fas fa-graduation-cap fa-9x opacity-25"></i>
            </div>

        </div>
    </div>
</section>


<!-- ================= MAIN ================= -->
<main class="container my-5">

    <!-- ACTIONS -->
    <div class="row g-4 mb-5 reveal">
        <div class="col-md-3">
            <div class="action-card"><i class="fas fa-calendar-check"></i>
                <h6>Events</h6>
            </div>
        </div>
        <div class="col-md-3">
            <div class="action-card"><i class="fas fa-file-signature"></i>
                <h6>Memos</h6>
            </div>
        </div>
        <div class="col-md-3">
            <div class="action-card"><i class="fas fa-monument"></i>
                <h6>History</h6>
            </div>
        </div>
        <div class="col-md-3">
            <div class="action-card"><i class="fas fa-sitemap"></i>
                <h6>Org. Chart</h6>
            </div>
        </div>
    </div>

    <!-- STORY -->
    <section class="row align-items-center g-5 mb-5 reveal">
        <div class="col-lg-6">
            <h3 class="section-title">Our Story</h3>
            <p class="fs-5">
                ANHS began as a small institution with a bold vision —
                to empower young minds through transformative education.
            </p>
            <p class="text-muted">
                Over the decades, we evolved into a center of excellence,
                producing graduates who excel in leadership, science, arts,
                and technology.
            </p>
        </div>

        <div class="col-lg-6">
            <div class="story-img shadow">
                <img src="https://scontent.fceb2-2.fna.fbcdn.net/v/t39.30808-6/541104288_3126062164213230_4751342476885033487_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeGZaIM3DyEJhTWozpGq0pKAEPzI1G4W4w8Q_MjUbhbjD_do2UjlyLj_Kr7lwl6puRP3au6KgD8X-MEid8vqO4Mw&_nc_ohc=PLgHjmXoYm4Q7kNvwHEfBJo&_nc_oc=AdliBBBZOhRadUQzULx3fRGppKRcy28Dx8feL8CpkaE7hKJxGmV1IFK796ysz8iTM5c&_nc_zt=23&_nc_ht=scontent.fceb2-2.fna&_nc_gid=-MdKFfwxDcMkIt6y-YXShw&oh=00_AftWd_m8V4_wcg87c_QBXW1iSe9HseRcHmebP5Hb_1H1eA&oe=699C60D0"
                    class="img-fluid" alt="Students">
            </div>
        </div>
    </section>

    <!-- ENROLLMENT -->
    <section class="row g-5 reveal">
        <div class="col-lg-6">
            <div class="enrollment-card">
                <h4 class="section-title">Enrollment Overview</h4>

                <div class="mb-3">
                    <small>Grade 7</small>
                    <div class="progress">
                        <div class="progress-bar" style="width:85%"></div>
                    </div>
                </div>

                <div class="mb-3">
                    <small>Grade 8</small>
                    <div class="progress">
                        <div class="progress-bar" style="width:75%"></div>
                    </div>
                </div>

                <div class="mb-3">
                    <small>Grade 9</small>
                    <div class="progress">
                        <div class="progress-bar" style="width:70%"></div>
                    </div>
                </div>

                <button class="btn btn-dark w-100 mt-4 rounded-pill">
                    View Full Report
                </button>
            </div>
        </div>

        <div class="col-lg-6 d-flex align-items-center">
            <div>
                <h3 class="section-title">Why Choose ANHS?</h3>
                <ul class="list-unstyled fs-5">
                    <li>✔ Modern Enrollment System</li>
                    <li>✔ Award-Winning Faculty</li>
                    <li>✔ Smart Classrooms</li>
                    <li>✔ Leadership & Innovation Focus</li>
                </ul>
            </div>
        </div>
    </section>

</main>

<script>
    window.addEventListener('scroll', function() {
        document.querySelectorAll('.reveal').forEach(function(el) {
            if (el.getBoundingClientRect().top < window.innerHeight - 100) {
                el.classList.add('active');
            }
        });
    });
</script>

<?php include 'nav/footer.php'; ?>