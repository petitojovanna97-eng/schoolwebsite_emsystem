<?php
require_once 'server.php';

class AuthenticationModel extends Connector
{
    public function __construct()
    {
        parent::__construct();
    }

    // ---------------------------
    // LOGIN FUNCTION
    // ---------------------------
    public function login($username, $password)
    {
        $sql = "SELECT * FROM users WHERE user_name = :username LIMIT 1";

        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            ':username' => $username
        ]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verify hashed password
        if ($user && password_verify($password, $user['user_pass'])) {
            return $user;
        }

        return false;
    }

    // ---------------------------
    // REGISTER FUNCTION
    // ---------------------------
    public function register($username, $password, $role)
    {
        // Hash password before saving
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (user_name, user_pass, user_role) 
                VALUES (:username, :password, :role)";

        $stmt = $this->conn->prepare($sql);

        return $stmt->execute([
            ':username' => $username,
            ':password' => $hashedPassword,
            ':role'     => $role
        ]);
    }
} 