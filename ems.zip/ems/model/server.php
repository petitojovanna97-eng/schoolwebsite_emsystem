<?php
class Connector
{
    private $servername = "localhost";
    private $username   = "root";
    private $password   = "";
    private $dbname     = "ems_db";

    protected $conn;

    public function __construct()
    {
        try {
            $dsn = "mysql:host={$this->servername};dbname={$this->dbname};charset=utf8mb4";

            $this->conn = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die("Database connection failed.");
            // In production, log error instead of showing it:
            // error_log($e->getMessage());
        }
    }

    // INSERT, UPDATE, DELETE
    public function executeUpdate($sql, $params = [])
    {
        try {
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->rowCount(); // returns number of affected rows
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    // SELECT
    public function executeQuery($sql, $params = [])
    {
        try {
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    // Optional: get last inserted ID
    public function lastInsertId()
    {
        return $this->conn->lastInsertId();
    }
}
